#Demonstration of SEMs
import core.SEMs as SEMs
import numpy as np
import pandas as pd
np.random.seed(123)

BATCH_SIZE = 3

speed = SEMs.node(name = "Speed",
                  SE = SEMs.identity_SE(),
                  intervenable = True,
                  measurable = True,
                  is_treatment = True,
                  is_target = False
                  )

chup_flow = SEMs.node(name = "Chup Flow",
                      SE = SEMs.linear_SE(coefficients_dict = {"Speed":1,"Feed Rate":0.5}, number_incoming_edges = 2),
                      intervenable=False,
                      measurable = False,
                      is_treatment = False,
                      is_target = False
                      )

wear = SEMs.node(name = "Wear",
                 SE = SEMs.identity_SE(),
                 intervenable = False,
                 measurable = True,
                 is_treatment = False,
                 is_target = False
                 )

cutting_force = SEMs.node(name = "Cutting Force",
                          SE = SEMs.linear_SE_inhomogeneous_error(coefficients_dict = {"Speed":1,"Feed Rate":-0.5,"Wear":0.5,"U":0.6}, number_incoming_edges = 3),
                          intervenable = False,
                          measurable = True,
                          is_treatment = False,
                          is_target = False
                          )

feed_rate = SEMs.node(  name = "Feed Rate",
                        SE = SEMs.identity_SE(),
                        intervenable = True,
                        measurable = True,
                        is_treatment = True,
                        is_target = False
                        )

drift = SEMs.node(  name = "Drift",
                    SE = SEMs.tanh_SE(coefficients_dict = {"Chup Flow":1,"Cutting Force":0.5}, number_incoming_edges = 2),
                    intervenable = False,
                    measurable = True,
                    is_treatment = False,
                    is_target = True
                    )

vertices=[speed, chup_flow, wear, cutting_force, feed_rate, drift]
n_vertices = len(vertices)
edge_matrix = np.zeros((n_vertices,n_vertices),dtype=bool)
vertex_index={vertices[i].name:i for i in range(n_vertices)}
edge_matrix[vertex_index["Speed"],vertex_index["Chup Flow"]]=1
edge_matrix[vertex_index["Speed"],vertex_index["Cutting Force"]]=1
edge_matrix[vertex_index["Cutting Force"],vertex_index["Drift"]]=1
edge_matrix[vertex_index["Feed Rate"],vertex_index["Cutting Force"]]=1
edge_matrix[vertex_index["Feed Rate"],vertex_index["Chup Flow"]]=1
edge_matrix[vertex_index["Chup Flow"],vertex_index["Drift"]]=1
edge_matrix[vertex_index["Wear"],vertex_index["Cutting Force"]]=1


M=SEMs.graph(name = "DemoGraph",
             vertices = vertices,
             edge_matrix = edge_matrix,
             verbose = True)
M.do_reset_before_simulation = True

U_SPEED = np.random.poisson(lam=5.2,size=BATCH_SIZE).astype(np.float64)
U_DRIFT = np.random.poisson(lam=1.2,size=BATCH_SIZE).astype(np.float64)

dict_of_Us = {"Speed":U_SPEED,
              "Feed Rate":None,
              "Drift":U_DRIFT,
                "Wear":None,
                "Cutting Force":None,
                "Chup Flow":None}

results = M.simulate(dict_of_Us = dict_of_Us,
           batch_size = BATCH_SIZE)


#Run some tests to see if evaluation happened as desired
for v in M.vertices_dict["Chup Flow"][0].parents:
    print(v.name)

Chup_Flow_Value = M.vertices_dict["Chup Flow"][0].value
Speed_Value = M.vertices_dict["Speed"][0].value
Feed_Rate_Value = M.vertices_dict["Feed Rate"][0].value

Chup_Flow_SE = M.vertices_dict["Chup Flow"][0].SE
assert M.vertices_dict["Speed"][1] < M.vertices_dict["Feed Rate"][1]
Chup_Flow_Value_calculation = Chup_Flow_SE(input_dict={
                                            "Speed":Speed_Value,
                                            "Feed Rate":Feed_Rate_Value,
                                            "U": M.vertices_dict["Chup Flow"][0].U})


assert np.allclose(Chup_Flow_Value,Chup_Flow_Value_calculation)

print(results["endogeneous"])
print(results["exogeneous"])

print("Demo finished")