#import debugging.IPW_debugging as IPW_debugging
import core.global_params as global_params
import sys
sys.path.append(global_params.PROJECT_PATH)


#import everything from the dowhy-main package/folder
import dowhy_main.dowhy as dowhy


import core.IPW as IPW
import core.SEMs as SEMs
import core.global_params as global_params
import notebooks.plots as plots
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
import matplotlib.pyplot as plt
import copy
import importlib
#importlib.reload(IPW_debugging)
importlib.reload(IPW)

seed = global_params.SEED
np.random.seed(seed)

BATCH_SIZE = 700

#Define Nodes and their Structural Equations
speed = SEMs.node(name = "Speed",
                  SE = SEMs.identity_SE(),
                  intervenable = True,
                  measurable = True,
                  is_treatment = True,
                  is_target = False
                  )

chip_flow = SEMs.node(name = "ChipFlow",
                      SE = SEMs.thresholding_SE(coefficients_dict = {"Speed":-0.2,"FeedRate":0.5}, number_incoming_edges = 2, thresh = 0.0),
                      intervenable=False,
                      measurable = False,
                      is_treatment = False,
                      is_target = False
                      )

wear = SEMs.node(name = "Wear",
                 SE = SEMs.identity_SE(),
                 intervenable = False,
                 measurable = True,
                 is_treatment = False,
                 is_target = False
                 )

cutting_force = SEMs.node(name = "CuttingForce",
                          SE = SEMs.linear_SE_inhomogeneous_error(coefficients_dict = {"Speed":1,"FeedRate":-1.5,"Wear":0.5,"U":0.6}, number_incoming_edges = 3),
                          intervenable = False,
                          measurable = True,
                          is_treatment = False,
                          is_target = False
                          )

feed_rate = SEMs.node(  name = "FeedRate",
                        SE = SEMs.identity_SE(),
                        intervenable = True,
                        measurable = True,
                        is_treatment = True,
                        is_target = False
                        )

drift = SEMs.node(  name = "Drift",
                    SE = SEMs.linear_SE(coefficients_dict = {"ChipFlow":0.3,"CuttingForce":0.7}, number_incoming_edges = 2),
                    intervenable = False,
                    measurable = True,
                    is_treatment = False,
                    is_target = True
                    )

# Create the edge matrix
vertices=[speed, chip_flow, wear, cutting_force, feed_rate, drift]
n_vertices = len(vertices)
edge_matrix = np.zeros((n_vertices,n_vertices),dtype=bool)
vertex_index={vertices[i].name:i for i in range(n_vertices)}
edge_matrix[vertex_index["Speed"],vertex_index["ChipFlow"]]=1
edge_matrix[vertex_index["Speed"],vertex_index["CuttingForce"]]=1
edge_matrix[vertex_index["CuttingForce"],vertex_index["Drift"]]=1
edge_matrix[vertex_index["FeedRate"],vertex_index["CuttingForce"]]=1
edge_matrix[vertex_index["FeedRate"],vertex_index["ChipFlow"]]=1
edge_matrix[vertex_index["ChipFlow"],vertex_index["Drift"]]=1
edge_matrix[vertex_index["Wear"],vertex_index["CuttingForce"]]=1

# Create the graph
M=SEMs.graph(name = "DebuggingBinaryGraph",
             vertices = vertices,
             edge_matrix = edge_matrix,
             verbose = False)


#For Simulation, manually set the Us you want to set
U_SPEED = np.random.poisson(lam=3.2,size=BATCH_SIZE).astype(np.float64)
U_DRIFT = np.random.normal(size=BATCH_SIZE).astype(np.float64)
U_FEED_RATE = np.random.normal(size=BATCH_SIZE).astype(np.float64)
U_WEAR = np.random.normal(size=BATCH_SIZE).astype(np.float64)
U_CUTTING_FORCE = np.random.normal(size=BATCH_SIZE).astype(np.float64)
U_CHIP_FLOW = np.random.normal(size=BATCH_SIZE).astype(np.float64)

dict_of_Us = {"Speed":U_SPEED,
              "FeedRate":U_FEED_RATE,
              "Drift":U_DRIFT,
                "Wear":U_WEAR,
                "CuttingForce":U_CUTTING_FORCE,
                "ChipFlow":U_CHIP_FLOW}

results = M.simulate(dict_of_Us = dict_of_Us,
           batch_size = BATCH_SIZE)

print(results["endogeneous"])


data = IPW.dataset(df = results["endogeneous"],
                    treatment="ChipFlow",
                    treatment_type="discrete",
                    target="Drift",
                    adjustment_variables=["Speed","FeedRate"])


#Calculate the IPW weights
Weights = IPW.WeightCalculator(method_name="logistic regression", stabilized = False)
WA_obj = Weights(data)
WA = WA_obj.weights

#Extract the model
logistic_model = WA_obj.model.logistic_model
formula = logistic_model.model.formula
formula = "ChipFlow ~ 1 + Speed + FeedRate" #We do it manually bcs the Q(..) may be causing issues in dowhy.
# Access the original data from the fitted model
logistic_model_data = logistic_model.model.data.orig_endog, logistic_model.model.data.orig_exog
data_df = logistic_model.model.data.frame
unfitted_logistic_model = smf.logit(formula=formula, data=data_df)
fitted_logistic_model = copy.deepcopy(unfitted_logistic_model).fit()


#propensity_scores = fitted_logistic_model.predict(data_df)
propensity_scores = fitted_logistic_model.predict(data.data[["Speed","FeedRate"]])

data.data["propensity_score"] = propensity_scores


GML_model_string = """graph [
  directed 1
  
  node [
    id 0
    label "ChipFlow"
    pos "-1.969,-0.973"
  ]
  
  node [
    id 1
    label "CuttingForce"
    pos "0.153,1.709"
  ]
  
  node [
    id 2
    label "FeedRate"
    pos "0.126,-1.020"
  ]
  
  node [
    id 3
    label "Drift"
    pos "-1.995,1.709"
  ]
  
  node [
    id 4
    label "Speed"
    pos "-0.932,0.376"
  ]
  
  node [
    id 5
    label "Wear"
    pos "0.941,1.207"
  ]
  
  edge [
    source 0
    target 3
  ]
  
  edge [
    source 1
    target 3
  ]
  
  edge [
    source 2
    target 0
  ]
  
  edge [
    source 2
    target 1
  ]
  
  edge [
    source 4
    target 0
  ]
  
  edge [
    source 4
    target 1
  ]
  
  edge [
    source 5
    target 1
  ]
]
"""

#This came from ChatGPT conversion

model = dowhy.CausalModel(
    data=data.data,
    treatment="ChipFlow",
    outcome="Drift",
    graph=GML_model_string
)
model.view_model()
from dowhy.causal_estimators.propensity_score_estimator import PropensityScoreEstimator
from dowhy.causal_estimators.propensity_score_weighting_estimator import PropensityScoreWeightingEstimator

identified_estimand = model.identify_effect(proceed_when_unidentifiable=True, method_name="default")
identified_estimand2 = model.auto_identify_effect()
# Manually specify the backdoor variables
preferred_backdoor_set = ["Speed", "FeedRate"]
"""
estimator = PropensityScoreEstimator(
    data = data.data,
    treatment="ChipFlow",
    outcome="Drift",
    identified_estimand=identified_estimand,
    propensity_score_model=unfitted_logistic_model)

#This fails for unknown reasons
"""

estimate = model.estimate_effect(
    identified_estimand,
    method_name="backdoor.propensity_score_weighting",
    method_params={"propensity_score_model": unfitted_logistic_model,
                   "backdoor_variables": preferred_backdoor_set}
)



estimator = PropensityScoreWeightingEstimator(
    data = data.data,
    treatment="ChipFlow",
    outcome="Drift",
    identified_estimand=identified_estimand,
    propensity_score_model=fitted_logistic_model)

