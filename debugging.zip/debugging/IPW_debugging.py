#Demonstration of SEMs
import core.SEMs as SEMs
import core.global_params as global_params
import numpy as np
import pandas as pd
np.random.seed(123)

BATCH_SIZE = 700

#Define Nodes and their Structural Equations
speed = SEMs.node(name = "Speed",
                  SE = SEMs.identity_SE(),
                  intervenable = True,
                  measurable = True,
                  is_treatment = True,
                  is_target = False
                  )

chup_flow = SEMs.node(name = "Chup Flow",
                      SE = SEMs.linear_SE(coefficients_dict = {"Speed":1,"Feed Rate":0.5}, number_incoming_edges = 2),
                      intervenable=False,
                      measurable = False,
                      is_treatment = False,
                      is_target = False
                      )

wear = SEMs.node(name = "Wear",
                 SE = SEMs.identity_SE(),
                 intervenable = False,
                 measurable = True,
                 is_treatment = False,
                 is_target = False
                 )

cutting_force = SEMs.node(name = "Cutting Force",
                          SE = SEMs.linear_SE_inhomogeneous_error(coefficients_dict = {"Speed":1,"Feed Rate":-0.5,"Wear":0.5,"U":0.6}, number_incoming_edges = 3),
                          intervenable = False,
                          measurable = True,
                          is_treatment = False,
                          is_target = False
                          )

feed_rate = SEMs.node(  name = "Feed Rate",
                        SE = SEMs.identity_SE(),
                        intervenable = True,
                        measurable = True,
                        is_treatment = True,
                        is_target = False
                        )

drift = SEMs.node(  name = "Drift",
                    SE = SEMs.tanh_SE(coefficients_dict = {"Chup Flow":1,"Cutting Force":0.5}, number_incoming_edges = 2),
                    intervenable = False,
                    measurable = True,
                    is_treatment = False,
                    is_target = True
                    )

# Create the edge matrix
vertices=[speed, chup_flow, wear, cutting_force, feed_rate, drift]
n_vertices = len(vertices)
edge_matrix = np.zeros((n_vertices,n_vertices),dtype=bool)
vertex_index={vertices[i].name:i for i in range(n_vertices)}
edge_matrix[vertex_index["Speed"],vertex_index["Chup Flow"]]=1
edge_matrix[vertex_index["Speed"],vertex_index["Cutting Force"]]=1
edge_matrix[vertex_index["Cutting Force"],vertex_index["Drift"]]=1
edge_matrix[vertex_index["Feed Rate"],vertex_index["Cutting Force"]]=1
edge_matrix[vertex_index["Feed Rate"],vertex_index["Chup Flow"]]=1
edge_matrix[vertex_index["Chup Flow"],vertex_index["Drift"]]=1
edge_matrix[vertex_index["Wear"],vertex_index["Cutting Force"]]=1

# Create the graph
M=SEMs.graph(name = "DemoGraph",
             vertices = vertices,
             edge_matrix = edge_matrix,
             verbose = False)


#For Simulation, manually set the Us you want to set
U_SPEED = np.random.poisson(lam=5.2,size=BATCH_SIZE).astype(np.float64)
U_DRIFT = np.random.poisson(lam=1.2,size=BATCH_SIZE).astype(np.float64)
U_FEED_RATE = np.random.normal(size=BATCH_SIZE).astype(np.float64)
U_WEAR = np.random.normal(size=BATCH_SIZE).astype(np.float64)
U_CUTTING_FORCE = np.random.normal(size=BATCH_SIZE).astype(np.float64)
U_CHUP_FLOW = np.random.normal(size=BATCH_SIZE).astype(np.float64)

dict_of_Us = {"Speed":U_SPEED,
              "Feed Rate":U_FEED_RATE,
              "Drift":U_DRIFT,
                "Wear":U_WEAR,
                "Cutting Force":U_CUTTING_FORCE,
                "Chup Flow":U_CHUP_FLOW}

results = M.simulate(dict_of_Us = dict_of_Us,
           batch_size = BATCH_SIZE)

print(results["endogeneous"])


#Diagnostics

def summary(vector):
    print("First 5 elements: ",vector[:5])
    print("Mean: ",np.mean(vector))
    print("Standard Deviation: ",np.std(vector))
    print("Minimum: ",np.min(vector))
    print("Maximum: ",np.max(vector))
    print("Median: ",np.median(vector))
    print("25th Percentile: ",np.percentile(vector,25))
    print("75th Percentile: ",np.percentile(vector,75))

import matplotlib.pyplot as plt
def weight_histogram(weights):
    n=len(weights // 7)
    d=n//5
    #Here is a very pretty and useful histogram of the weights.
    bins=np.arange(n,dtype=np.float64)/d
    bins = np.concatenate((bins,np.array([np.inf])))
    plt.hist(weights,bins=bins)
    plt.xlabel("Weight")
    plt.ylabel("Frequency")
    plt.title("Histogram of Weights")
    plt.savefig("Weight_Histogram.png")
    plt.show()


from scipy.stats import norm

def plot_treatment(data, treatment_name):
    # Histogram of the treatment with density
    treatment_values = data.data[treatment_name]
    plt.hist(treatment_values, bins=30, density=True, alpha=0.6)

    # Fit a normal distribution and superimpose it
    mu, std = norm.fit(treatment_values)  # Fit mean and stddev of the data
    xmin, xmax = plt.xlim()
    x = np.linspace(xmin, xmax, 100)
    p = norm.pdf(x, mu, std)
    #plot normal curve in red
    plt.plot(x, p, 'r', linewidth=2)

    plt.xlabel("Treatment")
    plt.ylabel("Density")
    plt.title("Histogram of Treatment with Fitted Normal Distribution")
    plt.savefig("Treatment_Histogram.png")
    plt.show()

def diagnose(data, weights:np.array, fitted_weightcalculator):
    """
    :param data: IPW.dataset
    :param weights: np.array
    :param fitted_weightcalculator: IPW.WeightCalculator
    """
    weight_histogram(weights)
    plot_treatment(data,"Chup Flow")
    expectation_A_given_Z =...
    fitted_weightcalculator.model_f_A_given_Z(data.data)
    stddev_given_Z = fitted_weightcalculator.stddev_given_Z
    plt.scatter(x=np.arange(len(expectation_A_given_Z)),
                y=max(-20,min((data.data["Chup Flow"]-expectation_A_given_Z)/stddev_given_Z,20)),
                s=weights*5)
    plt.xlabel("Index")
    plt.ylabel("Standardized Residual")
    plt.title("Standardized Residuals of Chup Flow")
    path = global_params.PROJECT_PATH + "/debugging/Standardized_Residuals.png"
    plt.savefig(path)
    plt.show()






#Calculate Weights
    
import core.IPW as IPW
Weights = IPW.WeightCalculator(method_name="linearly parameterized normal", stabilized = True)

data=IPW.dataset(df=results["endogeneous"],
                 treatment="Chup Flow",
                 treatment_type="continuous",
                 target="Drift",
                 adjustment_variables=["Speed","Feed Rate"])


SWA_obj=Weights(data)
SWA = SWA_obj.weights
print(summary(SWA))
#diagnose(data,WA,Weights)

Weights = IPW.WeightCalculator(method_name="linearly parameterized normal", stabilized = False)
WA_obj = Weights(data)
WA = WA_obj.weights
print(summary(WA))
#diagnose(data,WA,Weights)



RF_Weights = IPW.WeightCalculator(method_name = "RF_mean_normal", stabilized = False)
WA_RF_obj = RF_Weights(data)
WA_RF = WA_RF_obj.weights

print(summary(WA_RF))
#diagnose(data,WA_RF,RF_Weights)

RF_Weights = IPW.WeightCalculator(method_name = "RF_mean_normal", stabilized = True)
SWA_RF_obj = RF_Weights(data)
SWA_RF = SWA_RF_obj.weights

print(summary(SWA_RF))
#diagnose(data,WA_RF,RF_Weights)

