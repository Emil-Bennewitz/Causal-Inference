import core.IPW as IPW
import core.SEMs as SEMs
import core.utile as utile
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


A = SEMs.node(name="A",
              intervenable=True,
              SE=SEMs.identity_SE(),
              measurable=True,
              is_treatment=False,
              is_target=False)

B = SEMs.node(name="B",
              intervenable=True,
              SE=SEMs.linear_SE(coefficients_dict = {"A":2,"C":0.5}, number_incoming_edges = 2),
              measurable=True,
              is_treatment=False,
              is_target=False)

C = SEMs.node(name="C",
              intervenable=True,
              SE=SEMs.linear_SE(coefficients_dict = {"A":1}, number_incoming_edges = 1),
              measurable=True,
              is_treatment=True,
              is_target=False)

D = SEMs.node(name="D",
              intervenable=True,
              SE=SEMs.linear_SE(coefficients_dict={"B":1, "C":1}, number_incoming_edges=2),
              measurable=True,
              is_treatment=False,
              is_target=True)

edge_matrix = utile.create_edge_matrix(vertices=[A, B, C, D],
                         edges=[("A", "B"), ("A","C"), ("C", "D"),("B","D"),("C","B")])

M = SEMs.graph(name= "debug_do_graph",
    vertices=[A,B,C,D],
               edge_matrix=edge_matrix,
               )
batchsize = 1000
dict_of_Us = {"A":np.random.normal(2,1,batchsize),
              "B":np.random.normal(0,1,batchsize),
              "C":np.random.normal(0,1,batchsize),
              "D":np.random.normal(0,1,batchsize)}
grid = np.linspace(0.0,5.0,100)
counterfactual_means=M.do(target_variable_name="D",intervention_variable_name="C",
     grid_of_intervention_values = grid,
     dict_of_Us= dict_of_Us, return_all_data=False)
fig=plt.figure()
plt.plot(grid, counterfactual_means)
plt.xlabel("Intervention Value")
plt.ylabel("Counterfactual Mean")
plt.title("Counterfactual Mean of D when intervening on C")
plt.savefig("debugging/Debug_do.png")