import os
SEED = 123

# Get the PATH to Causal Inference directory
PROJECT_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
