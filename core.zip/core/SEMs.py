import numpy as np
from abc import ABC, abstractmethod
import copy
from numpy.core.multiarray import array as array
import pandas as pd

class node:
    def __init__(self,name,SE,intervenable:bool,measurable:bool,is_treatment:bool,is_target:bool):
        """
        Parameters
        :param name: name of the node/variable
        :param intervenable: can the variable be intervened on?
        :param measurable: can the variable be measured?
        :param is_treatment: is the variable a treatment?
        :param is_target: is the variable the target variable of interest
        
        
        Following are class attributes, not parameters.
        :param evaluated: has it been evaluated yet, ie does it have a value?
        :param value: np.array, batch of values this variable takes.
        :param U: np.array, batch of exogeneous variables.
        :param SE: Structural Equation that defines the variable.
        :param graph: pointer to the graph this node is in.
        :param is_start: is the variable a starting node, ie one of the first in the graph? Is this where we start the simulation of the process?
        :param evaluatable: array of booleans, used when evaluating the graph. Its a vector to allow for batched input. Its true when all of the parents of the node have a value.
        Why an array? I know we have multiple points, but as their computation is identical, they should all be evaluatable at the same time. No need for array.
        
        """
        
        
        self.name=name
        #self.is_treatment=is_treatment #Currently seems like there's no need to encode this in the vertex or graph itself, just specify when simulating.
        #self.is_target=is_target
        self.intervenable=intervenable #can variable be intervened on?
        assert type(intervenable) == bool
        self.measurable=measurable
        if self.intervenable:
            assert self.measurable==True
        self.evaluatable = False
        #self.evaluated=np.full_like(self.evaluatable,False)
        self.evaluated = False
        self._value = None
        self._U = None

        self.original_type_of_SE = None
        self._SE=None
        self.SE=SE
        

        self.graph = None
        self._is_start = None

    @property 
    def SE(self):
        return self._SE 
    @SE.setter
    def SE(self,SE):
        #If no SE type has been set yet
        if self.original_type_of_SE is None:
            if isinstance(SE,StructuralEquation):
                #Set the type of SE for this node, so that it can't be changed later.
                self.original_type_of_SE = type(SE)
        else:
            #IF the node already has a type, check that you're setting it to the same type.
            #assert isinstance(SE,self.original_type_of_SE), f"SE must be of type {self.original_type_of_SE}. The type of Structural Equation is not allowed to change. This was implemented to fight bugs."
            pass #We don't actually want to ban changing the type, this is necessary for intervening on the graph. But we can put a conditional breakpoint here for debugging.
        self._SE=SE
    
    @property
    def is_start(self):
        return self._is_start
    
    @is_start.setter
    def is_start(self,boolean):
        assert(type(boolean) == bool or boolean == None)
        if boolean == True:
            self._is_start = True
            self.evaluatable = True
        elif boolean == False:
            print("Are you sure you want to reset vertex is_start to False? I can't see why you'd want to.")
            self._is_start = False

    @property
    def value(self):
        return self._value
    
    @value.setter
    def value(self,value):
        
        if value is not None:
            if value.dtype != np.float64:
                raise ValueError("{self.name}'s value must be a numpy array of floats (or None).")
            
        self._value=value

        #if the graph has verbose = true, signal this change for debugging/tracking purposes.
        if self.graph is not None:
            if self.graph.verbose:
                print(f"Value of {self.name} has been set to {value}")

    @property
    def U(self):
        return self._U
    @U.setter
    def U(self,U):
        if U is not None:
            if U.dtype != np.float64:
                raise ValueError("{self.name}'s U must be a numpy array of floats (or None).")

        self._U=U
        if self.graph is not None:
            if self.graph.verbose:
                print(f"U of {self.name} has been set to {U}")


    @property
    def parents(self):
        if self.graph is None:
            raise ValueError("Graph not set.")
        else:
            parent_indices=self.graph.get_parent_indices(self.graph.vertices_dict[self.name][1])
            result=[]
            for i in parent_indices:
                result.append(self.graph.vertices[i])
            return result

    @property
    def number_incoming_edges(self):
        if self.graph is None:
            raise ValueError("Graph not set.")
        else:
            parent_indices=self.graph.get_parent_indices(self.graph.vertices_dict[self.name][1])
            return len(parent_indices)

    def reset(self):
        self.U=None
        #don't think we actually want to reset U, both so we have the same behavior if we repeat a simulation, and because the user may have set the Us and theny they'd be lost.
        #actually its fine because the user can only provide U at the simulation now.
        
        self.value=None
        self.evaluated=False
        if self.is_start:
            self.evaluatable = True
        else:
            self.evaluatable=False


    def generate_U(self,n):
        """
        randomly generates a batch of exogeneous variables for the node if it hasn't been set already.
        """
        if self.U is not None:
            assert self.U.shape[0] == n
        else:
            self.U=np.random.normal(0,1,n)

    
from abc import ABC, abstractmethod

class StructuralEquation(ABC):  # Inherit from ABC
    
    #TODO: currently, the user must know the order of the vertices and make sure the SE is defined in that order. Ideally, we could specify the coefficients/whatever with their name, ie remap name to position.
    def __init__(self,number_incoming_edges:float, ordered_variables:list):
        """
        :param number_incoming_edges: number of incoming edges to the node. This is the number of variables that the node depends on.
        It's really only used to check dimensions.
        """
        self.number_incoming_edges = number_incoming_edges
        self.ordered_variables = ordered_variables
        

    # Subclasses must implement this method
    @abstractmethod 
    def __call__(self, input_dict) -> np.array:
        """Method that must be implemented in subclasses to return a batch of float.
        input_dict must have keys U,parent1_name,parent2_name,...,parentn_name, and values are numpy vectors of floats.
        """
        assert input_dict.keys() <= set(self.ordered_variables).union({"U"})
        #reorder the variables according to the coefficient order or manually specified order
        list_of_variables = [input_dict[name] for name in self.ordered_variables]
        if len(list_of_variables) == 0:
            random_variables = None
        else:
            random_variables=np.stack(list_of_variables,axis=1)
            assert self.number_incoming_edges==random_variables.shape[-1]
        exogeneous_U=input_dict["U"]
        
        return random_variables, exogeneous_U 


class SE_with_coefficients(StructuralEquation):
    """
    Subclass containing the shared __init__ for all SE that take a coefficient for every input, and then do something with it.
    :param coefficients_dict: dictionary with the names of the variables as keys and the coefficients as values. The coefficients are scalars. 
    This assumes that there is a one to one correspondence between the variables and the coefficients.
    Technically, I think it's not a problem if the coefficient keys are something other than the variable names, but that was what I had in mind when I wrote it.
    """
    def __init__(self,coefficients_dict:dict, number_incoming_edges:int, ordered_variables:list = None):
        if ordered_variables is not None:
            Warning("Ordered variables were specified in the structural equation with coefficients. This is not used, the order of the keys in the coefficients_dict is used.")
        variable_names = set(coefficients_dict.keys())
        variable_names.discard("U")
        ordered_variables = list(variable_names)
        super().__init__(number_incoming_edges, ordered_variables = ordered_variables)
            
        if "U" not in coefficients_dict.keys():
            print("Coefficient for U wasn't specified in the structural equation. Assuming U has a coefficient of 1.")
            coefficients_dict["U"]=np.array([1.0])
        self.coefficients = np.array([coefficients_dict[name] for name in self.ordered_variables])
        self.coefficient_for_U = coefficients_dict["U"]
        #assert self.coefficients.shape[-1]==self.number_incoming_edges
    
class identity_SE(StructuralEquation):
    """
    A structural equation of the type X=U_X.
    """
    def __init__(self,number_incoming_edges=0,input_dict = None):
        assert number_incoming_edges==0
        super().__init__(0,[])
    
    def __call__(self, input_dict) -> np.array:
        random_variables, exogeneous_U = super().__call__(input_dict)
        assert type(exogeneous_U) == np.ndarray and exogeneous_U.dtype == np.float64
        return exogeneous_U
    

class linear_SE(SE_with_coefficients):
    """
    A structural equation of the type Y=aX1+bX2+...+cXn+dU
    """
    #def __init__(self,coefficients_dict:dict, number_incoming_edges:int, ordered_variables:list):
    #    super().__init__(coefficients_dict = coefficients_dict, number_incoming_edges = number_incoming_edges)

    def __call__(self, input_dict) -> np.array:

        random_variables, exogeneous_U = super().__call__(input_dict)
        return random_variables@self.coefficients + self.coefficient_for_U*exogeneous_U
    
class linear_SE_inhomogeneous_error(SE_with_coefficients):
    """Structural Equation of the form Y=(aX1+bX2+...+cXn)(1+dU)
    May be a misnomer as is not really linear, idk if linear SE is an official term.
    """
    #def __init__(self,coefficients_dict:dict, number_incoming_edges:int):
        
    #    super().__init__(coefficients_dict,number_incoming_edges)
    
    def __call__(self, input_dict:dict) -> np.array:
        
        random_variables, exogeneous_U = super().__call__(input_dict)
        return random_variables@self.coefficients*(1+self.coefficient_for_U*exogeneous_U)


class tanh_SE(SE_with_coefficients):
    """
    A structural equation of the type Y=tanh(aX1+bX2+...+cXn+dU)
    """
    #def __init__(self,coefficients_dict,number_incoming_edges):
    #    super().__init__(coefficients_dict,number_incoming_edges)
    
    def __call__(self, input_dict:dict) -> np.array:
        random_variables, exogeneous_U = super().__call__(input_dict)
        return np.tanh(random_variables@self.coefficients + self.coefficient_for_U*exogeneous_U)

class thresholding_SE(SE_with_coefficients):
    """
    This structural equation creates a binary variable by thresholding tanh(a1 X1 + ...+ bU).
    """
    def __init__(self,coefficients_dict:dict, number_incoming_edges:int, ordered_variables:list = None, thresh=0.0):
        super().__init__(coefficients_dict,number_incoming_edges)
        self.thresh = thresh

    def __call__(self, input_dict) -> np.array:
        random_variables, exogeneous_U = super().__call__(input_dict)
        return (np.tanh(random_variables@self.coefficients + self.coefficient_for_U*exogeneous_U) > self.thresh).astype(np.float64)




class graph:

    def __init__(self,name:str, edge_matrix:np.array, vertices:list=None, verbose = False):
        if vertices is None: #mutable default argument bad
            vertices=[]
        self.vertices=copy.deepcopy(vertices)
        
        self.verbose = verbose
        
        for v in self.vertices:
            v.graph = self #update the pointer of the vertex to the graph
        self.vertices_dict={node.name:(node,i) for i,node in enumerate(self.vertices)} #transform vertices into a dictionary with key their name. Gives me access via position and name.
        
        self.name = name
        self.edge_matrix = edge_matrix

        
        #identify the start variables and start with those
        self.vertices_to_evaluate=np.zeros(shape=(self.n_vertices,),dtype=bool) #boolean mask
        for i,v in enumerate(self.vertices):
            if np.sum(edge_matrix[:,i]) == 0:
                v.is_start = True
            if v.evaluatable and not v.evaluated:
                self.vertices_to_evaluate[i]=1
    @property
    def n_vertices(self):
        return len(self.vertices)
    

    
    def get_parent_indices(self,vertex_index):
        mask=self.edge_matrix[:,vertex_index]
        parent_indices=np.where(mask==1)[0]
        return parent_indices
    
    def get_child_indices(self,vertex_index):
        mask=self.edge_matrix[vertex_index,:]
        child_indices=np.where(mask==1)[0]
        return child_indices
    
    def get_all_child_indices(self,vertex_indices:np.array)->np.array:
        """
        Get all the children of a set of vertices.
        :param vertex_indices: numpy vector of the indices of the set.
        """
        mask=self.edge_matrix[vertex_indices,:]
        mask=np.sum(mask,axis=0)
        all_child_indices=np.where(mask>=1)[0]
        return all_child_indices
    
    def recalculate_evaluability(self,vertex_index):
        vertex=self.vertices[vertex_index]
        if vertex.evaluatable: #you cannot become unevaluatable
            return True
        else:
            parent_indices = self.get_parent_indices(vertex_index)
            for PAi in parent_indices:
                if self.vertices[PAi].value is None:
                    assert vertex.evaluatable == False 
                    return False
            
            vertex.evaluatable = True
            return True
            
                
    def _set_Us(self,list_of_Us,batch_size):
        
        assert len(self.vertices)>0
        assert len(list_of_Us) == len(self.vertices)
        self.batch_size=batch_size
        for i,v in enumerate(self.vertices):
            assert (list_of_Us[i] is not None) and (batch_size == list_of_Us[i].shape[0])
            v.U = copy.deepcopy(list_of_Us[i])

    def _set_Us_with_names(self,dict_of_Us,batch_size):
        """
        Set the exogeneous variables for the graph. 
        Calls a subfunction, this function just prepares the input by ordering correctly.
        User-friendly because you can set the exogeneous variables by name.
        :param dict_of_Us: dictionary with the names of the nodes as keys and the exogeneous variables as values.
        """
        list_of_Us=[None]*len(self.vertices)
        for name,U in dict_of_Us.items():
            vertex_index=self.vertices_dict[name][1]
            list_of_Us[vertex_index]=U
        self._set_Us(list_of_Us,batch_size)


    def reset(self):
        if self.verbose:
            print("Resetting the graph.")
        self.vertices_to_evaluate=np.zeros(shape=(self.n_vertices,),dtype=bool) #boolean mask
            
        for i,v in enumerate(self.vertices):
            v.reset()
            if v.is_start == True:
                self.vertices_to_evaluate[i] = 1

        if self.verbose:
            print("Graph has been reset.")

    def _simulation_step(self):
        indices_to_evaluate=np.arange(self.n_vertices)[self.vertices_to_evaluate]
        
        if self.verbose:
            print(f"A new simulation step has been launched. indices to evaluate: {indices_to_evaluate}")

        for i in indices_to_evaluate:
            vertex=self.vertices[i]
            
            parent_mask=self.edge_matrix[:,i]
            #if there are no parents, evaluate
            if np.all(parent_mask == 0): 
                vertex.generate_U(n = self.batch_size) #generates a normal random U if it hasn't been set already. Superfluous the second time _simulation_step is called.
                SE_call_input_dict={"U":vertex.U}
                vertex.value = vertex.SE.__call__(input_dict=SE_call_input_dict)

            #if there are parents...
            else:
                n_parents=np.sum(parent_mask)
                parent_values=np.full(shape = (self.batch_size,n_parents), fill_value = 0.0, dtype = np.float64)
                SE_call_input_dict={}
                parent_names=[None]*n_parents
                
                #put the parents' values in a vector parent_values
                #as the order of input to the SE will be important, note also the names so we can do a consistency test that the order is correct/define SEs by the names of the inputs for convenience.
                
                parent_indices = self.get_parent_indices(i) #indices of parents of vertex i in self.vertices
                for j,parent_index in enumerate(parent_indices):
                    parent = self.vertices[parent_index]
                    #parent_values[:,j] = parent.value
                    #parent_names[j] = parent.name
                    SE_call_input_dict[parent.name] = parent.value

                #generate U if it hasnt been already, then evaluate the SE to update the value
                vertex.generate_U(n = self.batch_size)
                #This should be superfluous now, the user must set all Us.

                SE_call_input_dict["U"]=vertex.U
                vertex.value = vertex.SE(input_dict = SE_call_input_dict)
            vertex.evaluated=True 
        self.vertices_to_evaluate=np.zeros_like(self.vertices_to_evaluate,dtype=bool)#Kick these nodes from vertices_to_evaluate mask.
        #now, iterate over the children of this set to see which new nodes have become evaluatable.

        all_child_indices=self.get_all_child_indices(indices_to_evaluate)
            
        for child_index in all_child_indices:
            self.recalculate_evaluability(child_index)
            child = self.vertices[child_index]
            
            if child.evaluatable:
                assert not child.evaluated #sanity check, should never happen, as we just evaluated the parent.
                self.vertices_to_evaluate[child_index] = 1

        if all_child_indices.size == 0:
            return False # we are finished, not_finished==False
        else:
            return True
    

    def simulate(self,dict_of_Us,batch_size):
        """
        Simulates the entire system and returns value of target variable for convenience. Output is a list of numpy arrays, to allow for multiple target variables.
        Currently, do not simulate multiple times from the same graph! It will not work as expected.
        Update: Simulating multiple times should work now but has not been tested.
        The Us get stored as separate copies in the nodes. Don't worry about them getting overwritten, not that they get changed anyway.
        :param dict_of_Us: All exogeneous U must be manually set by the user. The keys are the names of the nodes, the values are the numpy arrays of the exogeneous variables.
        """
        self.reset()
        self._set_Us_with_names(dict_of_Us,batch_size)

        if self.verbose:
            iteration=0
        not_finished=True
        while not_finished:
            if self.verbose:
                iteration+=1
                print(f"iteration {iteration} commenced.")
            not_finished = self._simulation_step()
        
        results=self.results()

        """
        target_list=[]
        for i,v in enumerate(self.vertices):
            if v.target == True:
                target_list.append(copy.deepcopy(v.value))
                return target_list
        """
        
        return results
    
    def results(self):
        """returns pd.DataFrame of the full simulated dataset"""
        for i,v in enumerate(self.vertices):
            if v.value is None and v.measurable == True:
                raise ValueError("Not all nodes have been evaluated.")
        data_dict={copy.deepcopy(v.name):copy.deepcopy(v.value) for v in self.vertices}
        U_dict={"U_"+copy.deepcopy(v.name):copy.deepcopy(v.U) for v in self.vertices}
        return {"endogeneous":pd.DataFrame(data_dict),"exogeneous":pd.DataFrame(U_dict)}

    def get_modified_graph(self,names_of_intervened_variables:list):
        """
        Initializes a graph with the same structure, but where the corresponding edges have been removed.
        The structural equations have been set to identity for the intervened variables.
        The two graphs should be independent from each other.
        To simulate from the intervened graph, you must set U_X to the value you want to fix the intervened variable X to when you call simulate().
        """
        modified_list_of_vertices = copy.deepcopy(self.vertices)
        modified_edge_matrix=copy.deepcopy(self.edge_matrix)
        for name in names_of_intervened_variables:
            #modify edge matrix
            vertex_index=self.vertices_dict[name][1]
            modified_edge_matrix[:,vertex_index]=0
            
            #set the SE to identity
            vertex=self.vertices[vertex_index]
            modified_list_of_vertices[vertex_index] = copy.deepcopy(vertex)
            modified_list_of_vertices[vertex_index].SE=identity_SE() #This is not okay without deepcopying the vertices.
        
        #This is okay because the vertices get deepcopied in the __init__ anyway.
        return graph(name=self.name+" modified",edge_matrix=modified_edge_matrix,vertices=modified_list_of_vertices,verbose=self.verbose)
        
    def do(self, target_variable_name:str, intervention_variable_name:str, grid_of_intervention_values:np.array, dict_of_Us:dict, return_all_data:bool = False):
        """
        User-friendly way to simulate from the do(X=x) graph. Can apply do(X=xi) for every xi in the grid.
        Returns E[Y|do(X=xi)] for every xi in the grid, a numpy array. 
        If return_all_data is True, returns a list of the results of the simulation for every xi in the grid.
        Reuses the same Us for every xi in the grid (except for X, of course).
        """
        modified_graph = self.get_modified_graph([intervention_variable_name])
        grid = grid_of_intervention_values
        dict_of_Us = copy.deepcopy(dict_of_Us) # don't want to modify the Us in the original dict. 
        
        counterfactual_means = np.zeros_like(grid,dtype = np.float64)
        list_of_results = [None]*len(grid)
        # Extract batch_size from dict_of_Us and make sure all the Us are the same size.
        batch_size = None
        for name, U in dict_of_Us.items():
            if batch_size is None:
                batch_size = U.shape[0]
            if name != intervention_variable_name:
                assert U.shape[0] == batch_size

        for i,value in enumerate(grid):
            dict_of_Us[intervention_variable_name] = np.full(shape=(batch_size,), fill_value=value,dtype=np.float64)
            results = modified_graph.simulate(dict_of_Us,batch_size)

            # For purely debugging purposes:
            debugging_results = self.simulate(dict_of_Us,batch_size)

            list_of_results[i] = results
            counterfactual_means[i] = np.mean(results["endogeneous"][target_variable_name])
        
        if return_all_data:
            return list_of_results
        else:
            return counterfactual_means