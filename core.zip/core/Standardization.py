
import numpy as np
import pandas as pd
from core.IPW import dataset
from abc import abstractmethod
from abc import ABC


class generic_model(ABC):
    def __init__(self, model, model_name, adjustment_variable_names:list[str], treatment_variable_name:str, target_variable_name:str):
        self.model = model
        self.model_name = model_name
        self.adjustment_variables = adjustment_variable_names
        self.treatment_variable = treatment_variable_name
        self.target_variable = target_variable_name
    
    @abstractmethod
    def fit(self, data:pd.DataFrame):
        """
        Instances of this abstract class must implement this method, which trains the model on the dataframe supplied.
        Must contain columns that are named like self.adjustment_variables and self.treatment_variable.
        """
        pass
    
    @abstractmethod
    def _predict(self, data:pd.DataFrame, intervention_value:float):
        """
        Instances must implement this method.
        After having called fit, this method calculates E[y|Z=z_i,A=a] for each row in the data.
        """
        pass

    def predict(self,data:pd.DataFrame, intervention_value:float, k=1):
        """
        This method fits and predicts the counterfactual mean on the same dataset, by using sample splitting with k folds.
        The predictions for E[Y|intervention_value, z_i] are stored in self.predictions. Calls fit and _predict.

        Returns the average of the predictions, which is the estimate of E[Y^{intervention_value}].
        """
        
        if k>1:
            indices = data.index
            assert len(indices)>=k, "The number of folds must be less than the number of data points"
            permuted_indices = np.random.permutation(indices)
            fold_indices = np.array_split(permuted_indices, k)
            predictions_per_fold = [None]*k
            predictions = np.full((len(data),),np.nan,dtype=np.float64)
            for i in range(k):
                indices_of_fold_i = fold_indices[i]
                data_fold_i = data.iloc[indices_of_fold_i]
                training_indices = np.concatenate(fold_indices[:i] + fold_indices[i+1:])
                training_data = data.iloc[training_indices]
                self.fit(training_data)
                modified_data_fold_i = data_fold_i.copy()
                modified_data_fold_i[self.treatment_variable] = intervention_value
                predictions[fold_indices[i]] = self._predict(modified_data_fold_i, intervention_value)
            self.predictions = predictions
        
        else:
            self.fit(data)
            modified_data = data.copy()
            modified_data[self.treatment_variable] = intervention_value
            predictions = self._predict(modified_data, intervention_value)
            self.predictions = predictions
            #raise NotImplementedError
        
        return np.mean(predictions)
    
    def predict_all(self,data:pd.DataFrame, grid_of_intervention_values:np.array, k=1):
        """
        This method calls predict repeatedly for every intervention value in grid_of_intervention_values.
        Thus returns a numpy array of the same length as grid_of_intervention_values, with the corresponding predictions for E[Y^{intervention_value}].
        In the current implementation, not that self.predictions will get overwritten by the last call to predict.
        Not sure whether self.predictions is useful anyway.
        """
        predictions = np.full((len(grid_of_intervention_values),),np.nan,dtype=np.float64)
        for i in range(len(grid_of_intervention_values)):
            predictions[i] = self.predict(data, grid_of_intervention_values[i], k)
        return predictions
    

from sklearn.ensemble import RandomForestRegressor

class RF_model(generic_model):
    def __init__(self, model, model_name, adjustment_variable_names:list[str], treatment_variable_name:str, target_variable_name:str):
        assert isinstance(model, RandomForestRegressor), "The model must be a RandomForestRegressor."
        super().__init__(model, 
                         model_name, 
                         adjustment_variable_names=adjustment_variable_names, 
                         treatment_variable_name=treatment_variable_name, 
                         target_variable_name=target_variable_name)
    
    def fit(self, data:pd.DataFrame):
        X=np.concatenate((data[self.adjustment_variables].values,np.expand_dims(data[self.treatment_variable].values,axis = 1)), axis = 1)
        y = data[self.target_variable].values

        self.model.fit(X,y)
    
    def _predict(self, data:pd.DataFrame, intervention_value:float):
        X = np.concatenate((data[self.adjustment_variables].values, np.full((len(data),1),intervention_value,dtype=np.float64)), axis = 1)
        return self.model.predict(X)


# Now run the estimates on one specific dataframe of estimates for debugging/illustration
debugging = True
import os
import utile
import h5py
import matplotlib.pyplot as plt
from tqdm import tqdm
if debugging:
    file = os.path.join("data","samplesize","experiment_estimatesv03_linear.h5")
    hp_dict = {}
    with h5py.File(file, "r") as f:
        hp_names = f.attrs["hyperparameter_names"]
        grid_of_intervention_values = f.attrs["grid_of_intervention_values"]
        for key in hp_names:
            hp_dict[key] = f.attrs[key][0]
            
    sample_size = 400
    dataframes = utile.get_df_from_hdf5_experiment(file, hp_dict, sample_size, get_estimates=True, get_GPS=False)
    df_data = dataframes["df_data"]
    true_counterfactual_means = dataframes["true_counterfactual_means"]
    df_estimates = dataframes["df_estimates"]

    # Define the model to do standardization
    model = RandomForestRegressor(min_samples_leaf = 2, n_estimators = 100)
    RF = RF_model(model, 
                  model_name="RandomForestRegressor",
                  treatment_variable_name= "CuttingForce", 
                  adjustment_variable_names=["FeedRate","Speed"], 
                  target_variable_name="Drift")
    

    # read the existing estimates
    df_weighted = df_estimates[df_estimates["is_weighted"]==1]
    df_unweighted = df_estimates[df_estimates["is_weighted"]==0]
    colnames = [f"do(Treatment={grid_of_intervention_values[i]})" for i in range(len(grid_of_intervention_values))]
    IPW_estimates = df_weighted[colnames].values
    unweighted_estimates = df_unweighted[colnames].values

    
    #iterate over the batches
    n_batches = df_data["batchnr"].max()+1
    n_batches = 10 # make it faster
    IPW_estimates = IPW_estimates[:,:n_batches]
    unweighted_estimates = unweighted_estimates[:,:n_batches]

    estimates = np.full((len(grid_of_intervention_values),n_batches),np.nan,dtype=np.float64)
    estimatesv02 = np.full((len(grid_of_intervention_values),n_batches),np.nan,dtype=np.float64)
    for i in tqdm(range(n_batches)):
        df = df_data[df_data["batchnr"]==i]

        counterfactual_means = RF.predict_all(df, grid_of_intervention_values, k=1)
        #counterfactual_meansv02 = RF.predict_all(df, grid_of_intervention_values, k=5)
        counterfactual_meansv02 = np.full((len(grid_of_intervention_values),),np.nan,dtype=np.float64)

        estimates[:,i] = counterfactual_means
        estimatesv02[:,i] = counterfactual_meansv02
    
    

    #plot the graph
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.plot(grid_of_intervention_values, true_counterfactual_means, label="True Counterfactual Means", linestyle="--",color="red")
    ax.plot(grid_of_intervention_values, np.mean(estimates,axis=1), label="Estimates", color="blue")
    ax.fill_between(grid_of_intervention_values, np.quantile(estimates,0.025,axis=1), np.quantile(estimates,0.975,axis=1), color="blue", alpha=0.2)

    ax.plot(grid_of_intervention_values, np.mean(IPW_estimates,axis=1), label="IPW Estimates", color="green")
    ax.fill_between(grid_of_intervention_values, np.quantile(IPW_estimates,0.025,axis=1), np.quantile(IPW_estimates,0.975,axis=1), color="green", alpha=0.2)

    ax.plot(grid_of_intervention_values, np.mean(unweighted_estimates,axis=1), label="Unweighted Estimates", color="purple")
    ax.fill_between(grid_of_intervention_values, np.quantile(unweighted_estimates,0.025,axis=1), np.quantile(unweighted_estimates,0.975,axis=1), color="purple", alpha=0.2)
    
    #labels and titles
    ax.set_xlabel("Intervention Value")
    ax.set_ylabel("Counterfactual Mean")
    ax.set_title("Estimates of Counterfactual Means")
    ax.legend()

    fig.savefig("Standardization_Estimates.png")