import numpy as np
from numpy.core.multiarray import array as array
import pandas as pd
import os
import statsmodels.api as sm
import statsmodels.formula.api as smf
import core.global_params as global_params
import warnings

import pandas as pd
import patsy
from sklearn.ensemble import RandomForestRegressor

class dataset:
    def __init__(self,df:pd.DataFrame,treatment:str,treatment_type:str,target:str,adjustment_variables:list):
        self.data=df
        self.treatment:str = treatment
        assert treatment_type in ["continuous","discrete"], "Treatment type must be either 'continuous' or 'discrete'."
        self.treatment_type:str = treatment_type
        self.target:str = target
        self.adjustment_variables:list = adjustment_variables #list of names of the variables to adjust for to calculate the causal effect of the treatment
        
        self.modifier_variables:list = [] #list of variables that can modify the causal effect of the treatment. 
        #TODO: does this even belong in the dataset class?

        assert all(variable in self.adjustment_variables for variable in self.modifier_variables), "Modifier Variables should be in the adjustment set for now."

        self.target_type = None
    
    @property
    def effect_modification_is_present(self):
        return len(self.modifier_variables)>0



from abc import ABC, abstractmethod
import scipy.stats as stats
class abstract_model(ABC):
    def __init__(self,model_name:str):
        self.model_name = model_name
    
    @abstractmethod
    def predict(self,data:pd.DataFrame)->np.array:
        pass
    
    @abstractmethod
    def __call__(self,data:pd.DataFrame)->np.array:
        pass

#Output of the WeightCalculator
class WeightObject():
    def __init__(self,weights:np.array,method_name:str, stabilized:bool,weight_disparity_tol=50.0,verbose = False):
        self.weights = weights
        self.method_name = method_name
        self.stabilized = stabilized
        self.model = None
        self.f_A = None
        self.f_A_given_Z = None
        self.tol = weight_disparity_tol
        self.verbose = verbose
        self._trim_weights()

    def _recursively_remove_extreme_weight(self,w, tol = 50):
        """
        Assumes input w is sorted.
        """
        if len(w) <= 2:
            warnings.warn("Trimmed all the weights except two. This is weird and suggests either really weird weights or some bug.",Warning)
            return w
        
        # Most common exit condition: If we've removed enough weights that the ratio of the biggest to the smallest is less than tol.
        elif np.max(w)/np.min(w)<=tol:
            return w
        
        else:
            #remove first or last weight
            factor1 = w[-1]/w[1] #remove lowest weight
            factor2 = w[-2]/w[0] #remove highest weight
            if factor1 < factor2: #if its better to remove the lowest weight
                return self._recursively_remove_extreme_weight(w[1:],tol)
            else:
                return self._recursively_remove_extreme_weight(w[:len(w)-1],tol)
        
    def _trim_weights(self):
        """
        Huge weights are problematic. One approach is to trim them by removing extreme scores.
        Here we implement a greedy approach where we recursively remove the biggest or smallest weight until biggest/smalles <50.
        The removed points get trimmed to the new biggest/smallest weight and added back in.
        Some weights may be nan (typically really extreme weights where numerator or denominator is 0), these stay nan.
        """
        tol=self.tol
        subset_weights = self._recursively_remove_extreme_weight(np.sort(self.weights[np.isnan(self.weights) == False]),tol)
        lowest_acceptable_weight = np.min(subset_weights)
        highest_acceptable_weight = np.max(subset_weights)

        mask_smaller = self.weights < lowest_acceptable_weight
        mask_larger = self.weights > highest_acceptable_weight
        total_mask = mask_smaller + mask_larger
        assert total_mask.dtype == bool, "A weight cannot possibly be too small and too big simultaneously."
        mask_nan = np.isnan(self.weights) #nan weights are not trimmed per se but we count them as trimmed weights because they are also extreme weights.
        total_mask = total_mask | mask_nan

        self.mask_of_trimmed_weights = total_mask
        self.trimmed_weights = np.clip(self.weights,lowest_acceptable_weight,highest_acceptable_weight) #nan stays nan when clipping

    @property
    def number_of_trimmed_weights(self):
        return np.sum(self.mask_of_trimmed_weights)
    
    @property
    def trimmed_weight_indices(self):
        return np.nonzero(self.mask_of_trimmed_weights)[0]
    
    @property
    def percentage_of_trimmed_weights(self):
        return self.number_of_trimmed_weights/len(self.weights)*100
    
    @property
    def bounds_of_trimmed_weights(self):
        return np.min(self.trimmed_weights), np.max(self.trimmed_weights)

    def get_weights(self, trimmed:bool = False, renormalize_to = None)->np.array:
        if trimmed:
            if self.verbose:
                print(f"Trimmed {self.number_of_trimmed_weights} weights.")
                print("That is a percentage of ", self.percentage_of_trimmed_weights)
                print("The original minimum and maximum were: ", np.min(self.weights), np.max(self.weights))
                print("The trimmed weights have ew bounds of: ", self.bounds_of_trimmed_weights)
            
            if renormalize_to is None:
                result = self.trimmed_weights
            else:
                result = self.trimmed_weights*(renormalize_to/np.nanmean(self.trimmed_weights))
            
        else:
            if renormalize_to is None:
                result = self.weights
            else:
                result = self.weights*(renormalize_to/np.nanmean(self.weights))
        
        if np.any(np.isnan(result)):
            warnings.warn("There were nan weights. get_weights converted them to zero.")
        result[np.isnan(result)] == 0.0 
        return result
            

#Main Class implementing IPW weight calculation
class WeightCalculator():
    def __init__(self,method_name:str, stabilized:bool = False, nominator_method_name = None,additional_method_arguments:dict=None,verbose = False):
        
        self.verbose = verbose
        self.valid_method_types = ["continuous","discrete"]
        #assert method_type in self.valid_method_types
        #self.method_type = method_type
        self.valid_method_names = {"continuous":["linearly_parameterized_normal","RF_mean_normal","custom_linear_model"], "discrete":["logistic_regression"]}
        assert method_name in self.all_methods,"Method name not recognized."
        self.method_name = method_name
        self.stabilized = stabilized
        self.model_f_A_given_Z = None
        self._additional_method_arguments = additional_method_arguments

        self.methods_dict = {"linearly_parameterized_normal":self.linearly_parameterized_normal,
                                "RF_mean_normal":self.RF_mean_normal,
                                "logistic_regression":self.logistic_regression,
                                "custom_linear_model":self.custom_linear_model}
        self.nominator_methods_dict = {"normal":self._treatment_pmf_or_pdf} #Currently unused, as there is only one implementation for each treatment type for now.
        
    
    @property
    def all_methods(self):
        all_methods = []
        for method_type in self.valid_method_names.keys():
            all_methods.extend(self.valid_method_names[method_type])
        return all_methods
    
    def method_type(self,method_name:str)->str:
        if method_name in self.valid_method_names["continuous"]:
            return "continuous"
        elif method_name in self.valid_method_names["discrete"]:
            return "discrete"
        else:
            Warning("Method name not recognized.")
            return None


    def _check_and_construct_weights(self, f_A_given_Z, f_A=None):
        """
        To avoid copy pasting code for every method in __call__, this function checks that all weights are nonzero
        and constructs the weights, either stabilized or non-stabilized.
        :param f_A_given_Z: f_A|Z(ai|zi) for each sample, a numpy float vector.
        :param f_A: Optional argument. If supplied, calculates stabilized weights. It's f_A(ai) for each sample, a numpy float vector. If effect modification, can be f_A|V.
        """
        #assert np.all(f_A_given_Z > 0), "Denominator of IP weights f_A|Z had non-positive (zero) values."
        if f_A is not None:
            if not np.all(f_A>0):
                warnings.warn("Numerator of stabilized weights had non-positive (zero) values. \nWeight was set to np.nan. get_weights converts this to a zero.",Warning)
                f_A[f_A==0] = np.nan

            if not np.all(f_A_given_Z > 0):

                problematic_mask = ((f_A == 0) + (f_A_given_Z == 0)) != 0
                warnings.warn("Denominator of weights had non-positive (zero) values.")
                f_A_given_Z[f_A_given_Z == 0] = np.nan
            
            #assert np.all(f_A > 0), "Numerator of stabilized weights had non-positive (zero) values."
            SWA = f_A/f_A_given_Z
            if self.verbose:
                print("The mean of the stabilized weights is ", np.mean(SWA), f' over {len(SWA)} observations/weights.')
                print("For binary treatments ONLY, It should be close to one. Strong deviations indicate possible model misspecification or (near) violations of positivity.")
            return SWA
        else:

            WA = 1/f_A_given_Z
            if self.verbose:
                print("The mean of the unstabilized weights is ", np.mean(WA), f' over {len(WA)} observations/weights.')
                print("For binary treatments ONLY, it should be close to two. Strong deviations indicate possible model misspecification or (near) violations of positivity.")
            return WA
        
    def __call__(self, data:dataset)->np.array:
        """
        Returns a WeightObject with the calculated weights and an abstract_model subclass, which is really a wrapper class around the model fitted,
        so we can use the same syntax to get the predictions E[Y|A,Z] and f(Y|A,Z) from all models.
        Currently does not implement stabilized weights with effect modification, ie f_A|V in the numerator.

        The methods all return the model which is added to the output object so the user can do diagnostics and stuff. The wrapper is there because I created a model-agnostic plotting function.
        """
        f_A = None #if this is not assigned at some point, unstabilized weights are returned.

        method = self.methods_dict[self.method_name]
        model, f_A_given_Z = method(data)
        if self.stabilized:
            if data.effect_modification_is_present:
                raise NotImplementedError
            
            treatment_density_type = None #for now, numerator only has one implementation for discrete and continuous each.
            if data.treatment_type == "continuous":
                treatment_density_type = "normal"
            f_A = self._treatment_pmf_or_pdf(data, treatment_density_type = treatment_density_type)

        self.model_f_A_given_Z = model
        #Output the weights as an object with additional info.
        weights = self._check_and_construct_weights(f_A_given_Z, f_A)
        output = WeightObject(weights = weights, method_name = self.method_name, stabilized = self.stabilized)
        output.model = model
        output.f_A_given_Z = f_A_given_Z
        output.f_A = f_A
        return output
    
    def _create_formula(self, data:dataset,formula_RHS = None)->str:
        """
        This Function looks at data.adjustment_variables and data.treatment and creates a smf formula.
        The formula is the simple: treatment ~ 1 + Z_1 + Z_2 + ... + Z_k
        It should work with variable names with spaces etc.
        The optional argument formula_RHS can be used to pass a different RHS. In this case you perhaps might as well do it yourself.
        """
        
        #Patsy is particular about variable names (especially if they contain spaces). We need to convert them to Q objects.
        valid_adjustment_variables = [f'Q("{variable}")' for variable in data.adjustment_variables]
        valid_treatment = f'Q("{data.treatment}")'
        
        # Create the right-hand side formula
        
        if formula_RHS is None:
            formula_RHS = " + ".join(valid_adjustment_variables)

        # Construct the total formula
        if formula_RHS:
            total_formula = f'{valid_treatment} ~ 1 + {formula_RHS}'
        else:
            total_formula = f'{valid_treatment} ~ 1'
        return total_formula
    
    class linear_model_class(abstract_model):
            def __init__(self,fitted_model,treatment_name,model_name="generic linear model"):
                super().__init__(model_name=model_name)
                self.linear_model = fitted_model
                self.treatment = treatment_name
            def predict(self, new_data: pd.DataFrame) -> np.array:
                """
                This predicts the response in the formula. Can be a transformed version of the response variable if there is a transformation in the formula.
                """
                return self.linear_model.predict(new_data)
            
            def __call__(self,new_data:pd.DataFrame):
                """
                This returns f(A|Z) for each sample in new_data.
                """
                mu = self.linear_model.predict(new_data)
                sigma = np.sqrt(self.linear_model.scale) #scale gives residual variance, not sigma!!
                
                #if the response was transformed in the formula, apply same transformation here.
                formula=self.linear_model.model.formula
                dmatrices= patsy.dmatrices(formula,new_data)
                transformed_response = dmatrices[0][:].ravel() 
                densities = stats.norm.pdf(transformed_response, loc = mu, scale = sigma)
                assert densities.ndim == 1, "The GPS should be a 1D array"
                return densities
    
    def linearly_parameterized_normal(self,data:dataset, covariates = None)->np.array:
        """
        Estimates the Generalized Propensity Score by assuming P(A|Z) = N(mu, sigma)
        and mu = beta_0 + beta_1*Z_1 + ... + beta_k*Z_k
        ie, by fitting a linear model.
        """
        
        total_formula = self._create_formula(data)
        # Fit the OLS model
        lm_GPS = smf.ols(formula=total_formula, data=data.data).fit()

        # Print the summary of the model
        if self.verbose:
            print(lm_GPS.summary())

        #Define the function f_A|Z(a|z) for new samples
        f_A_given_Z_model:abstract_model = self.linear_model_class(fitted_model = lm_GPS,treatment_name = data.treatment, model_name = "linearly_parameterized_normal")
        f_A_given_Z = f_A_given_Z_model(data.data)
        return f_A_given_Z_model, f_A_given_Z
    
    
    def custom_linear_model(self, data:dataset):
        """
        The User specifies the formula for the linear model in __call__ as a keyword argument. Formula is not checked for validity (that correct adjustment variables are used).
        Returns the model and the predictions f_A|Z(a|z) for each sample.
        """
        if not "formula" in self._additional_method_arguments.keys():
            raise ValueError("No formula was passed to the custom linear model when instantiating the WeightCalculator.")
        formula = self._additional_method_arguments["formula"]
        # Fit the OLS model
        lm_GPS = smf.ols(formula=formula, data=data.data).fit()

        # Print the summary of the model
        if self.verbose:
            print(lm_GPS.summary())

        #Define the function f_A|Z(a|z) for new samples
        f_A_given_Z_model:abstract_model = self.linear_model_class(fitted_model = lm_GPS,treatment_name = data.treatment, model_name = "custom_linear_model")
        f_A_given_Z = f_A_given_Z_model(data.data)
        return f_A_given_Z_model, f_A_given_Z
    


    def logistic_regression(self,data:dataset,formula_RHS = None)->np.array:
        """
        Assumes binary treatment A = 0,1.
        Estimates the Propensity Score by assuming P(A|Z) = sigmoid(beta_0 + beta_1*Z_1 + ... + beta_k*Z_k)
        i.e., by fitting a logistic regression model.
        Another right-hand side formula can be passed as an argument.
        Returns propensity score P(A=1|zi) for each sample.
        """
        total_formula = self._create_formula(data = data, formula_RHS = formula_RHS)
        lm_GPS = smf.logit(formula= total_formula, data=data.data).fit()
        PS = lm_GPS.predict(data.data) #P(A=1|Z=zi)

        class logistic_model(abstract_model):
            def __init__(self):
                super().__init__(model_name="logistic_regression")
                self.logistic_model = lm_GPS
                self.treatment = data.treatment

            def predict(self,new_data:pd.DataFrame)->np.array:
                return self.logistic_model.predict(new_data)
            
            def __call__(self,new_data:pd.DataFrame):
                PS = self.logistic_model.predict(new_data)
                self.PS = PS
                A_is_1 = new_data[self.treatment] == 1
                A_is_0 = new_data[self.treatment] == 0
                f_A_given_Z = (PS*A_is_1 + (1-PS)*A_is_0)
                return f_A_given_Z
                

        model = logistic_model()
        f_A_given_Z = model(data.data)
        return model, f_A_given_Z
    

    def ML_mean_normal(self,data:dataset,mu)->np.array:
        """
        All this really does is transform predictions into normal densities. Ie input is E[A|Z=zi] (assumed to come from some ML model) and output is f_A|Z(ai|zi).
        The model can be given as argument to be passed right through 
        """
        sigma = np.std(data.data[data.treatment] - mu,ddof = 1) #ddof = 1 for unbiased estimate
        f_A_given_Z = stats.norm.pdf(data.data[data.treatment], loc = mu, scale = sigma)
        return f_A_given_Z
    
    def RF_mean_normal(self,data:dataset,n_estimators = 500, min_samples_leaf = 1)->np.array:
        """
        Estimates the Generalized Propensity Score by assuming P(A|Z) = N(mu, sigma)
        and mu = f(Z) where f is a machine learning model.
        This method specifically uses a Random Forest Regressor to estimate mu. Most parameters are left at default.

        returns GPS = f_A(a|z) for each sample.
        """

        model = RandomForestRegressor(n_estimators=n_estimators, min_samples_leaf = min_samples_leaf, random_state=global_params.SEED)
        model.fit(data.data[data.adjustment_variables],data.data[data.treatment])
        
        
        mu = model.predict(data.data[data.adjustment_variables])
        #self.expectation_A_given_Z = mu
        sigma = np.std(data.data[data.treatment] - mu,ddof = 1) #ddof = 1 for unbiased estimate
        """
        #self.stddev_given_Z = sigma

        f_A_given_Z = stats.norm.pdf(data.data[data.treatment], loc = mu, scale = sigma)
        
        if self.verbose:
            print("The standard deviation wrt to the random forest estimates is ", sigma)
            print("The MSE wrt to the random forest estimates is ", np.mean((data.data[data.treatment] - mu)**2))   #This is not important but I'm just checking that the fit works.
            print("Compare that to the variance of the treatment variable, ", np.var(data.data[data.treatment],ddof = 1))
        """
        class RF_model(abstract_model):
            def __init__(self,verbose):
                super().__init__(model_name="RF_mean_normal")
                self.verbose = verbose
                self.treatment = data.treatment
                self.adjustment = data.adjustment_variables
                self.model = model
                self.sigma = sigma
            
            def predict(self,new_data:pd.DataFrame)->np.array:
                return self.model.predict(new_data[self.adjustment])
            
            def __call__(self,new_data:pd.DataFrame):
                new_mu = self.model.predict(new_data[self.adjustment])
                
                if self.verbose:
                    print("The MSE wrt to the random forest estimates is ", np.mean((new_data[self.treatment] - new_mu)**2))   #This is not important but I'm just checking that the fit works.
                    print("Compare that to the variance of the treatment variable, ", np.var(new_data[self.treatment],ddof = 1))
                
                return stats.norm.pdf(new_data[self.treatment], loc = new_mu, scale = self.sigma)
        
        model = RF_model(verbose = self.verbose)
        f_A_given_Z = model(data.data)
        
        return model,f_A_given_Z
    
    def _treatment_pmf_or_pdf(self, data:dataset, treatment_density_type=None)->np.array:
        """
        :param treatment_density_type: "normal" or "None".
        If "normal", fits a normal distribution to the treatment variable to stabilize the weights in the numerator.
        Else, nonparametric estimates are used for the binary case.
        Returns f_A(a) for each sample.
        """
        if data.treatment_type == 'discrete':
            assert treatment_density_type is None
            P_A_is_1 = data.data[data.treatment].sum()/len(data.data)
            P_A_is_0 = 1 - P_A_is_1
            mask_A_is_1 = data.data[data.treatment] == 1
            mask_A_is_0 = data.data[data.treatment] == 0
            #return a vector of P(A = a) for each sample
            result = P_A_is_1*mask_A_is_1 + P_A_is_0*mask_A_is_0
            return result.to_numpy()
        
        elif data.treatment_type == 'continuous':
            if treatment_density_type == "normal":
                mu = data.data[data.treatment].mean()
                sigma = data.data[data.treatment].std()#in pandas is unbiased by default
                return stats.norm.pdf(data.data[data.treatment], loc = mu, scale = sigma)
            else:
                raise NotImplementedError
            

        raise ValueError("Treatment type not recognized.")
    
    