from scipy.linalg import solve
import numpy as np
import pandas as pd
import h5py

def loess(x_eval:np.array,x:np.array, y:np.array, bandwidth, span=1.0, degree=2, sample_weights = None):
    n = len(x)
    h = bandwidth
    if bandwidth is None:
        #set reasonable bandwidth automatically, 10% of the range of x if we have 100 datapoints. Ie if uniform, we expect 10 datapoints in a range of size h.
        #Set h a little higher than that for small datasets and lower for large datasets.
        h = 0.1 * (np.max(x) - np.min(x))*np.sqrt(100/n)
    min_weight_fraction = 1e-3 #only points whose weights are greater thatn 0.1% of the maximum weight are considered in the local regression.
    if sample_weights is None:
        sample_weights = np.ones(n)
    assert len(sample_weights) == n
    

    smoothed = np.zeros_like(x_eval)
    span_count = int(np.ceil(span * n))  # Number of neighbors used in local regression
    for i,x0 in enumerate(x_eval):
        range = np.max(x) - np.min(x)
        if x0 < np.min(x)-range/2 or x0 > np.max(x)+range/2:
            raise ValueError(f"x_eval[{i}] = {x0} is significantly outside the range of x.")
        # Define local window by computing distances
        distances = np.abs(x - x0)
        sorted_indices = np.argsort(distances)
        distance_weights = np.exp(-distances**2 / (h**2))/h
        mask = distance_weights > min_weight_fraction*np.max(distance_weights)
        sorted_indices = sorted_indices[:np.sum(mask)] 
        
        local_indices = sorted_indices[:span_count]
        #keep only the distances within the span count and such that their weights are not so small as to run into numerical error.
        
        if len(local_indices) < degree + 1:
            ValueError(f"Local window for x_eval[{i}] = {x0} is too small (too few neighbors) to fit a polynomial of degree {degree}.")

        # Local x and y
        x_local = x[local_indices]
        y_local = y[local_indices]
        
        # Fit a polynomial of given degree in the local window
        scale = 1/np.mean(x_local) #for numerical stability
        X_design = np.vander(x_local*scale, N=degree + 1, increasing=True)
        
        weights = np.exp(-distances[local_indices]**2 / (h**2))/h  # Gaussian weights
        weights = weights * sample_weights[local_indices]

        weights = weights / np.mean(weights) #normalize the weights so that they sum to 1.

        W = np.diag(weights)  # Diagonal weight matrix
        
        cond_nr = np.linalg.cond(X_design.T @ W @ X_design)

        if cond_nr > 10**10 or cond_nr < 10**(-10):

            pass #set breakpoint here to debug.
            return np.nan

        # Solve for coefficients using weighted least squares
        beta = solve(X_design.T @ W @ X_design, X_design.T @ W @ y_local)
        
        # Evaluate the polynomial at x[i]
        X_eval = np.vander([scale*x0], N=degree + 1, increasing=True)
        smoothed[i] = X_eval @ beta

    return smoothed


def dict_as_string(d:dict):
    return ', '.join([f"{k}={v}" for k,v in d.items()])

import copy 
def reverse_dict(d:dict):

    reverse_mapping = {}
    for key, value in copy.deepcopy(d).items():
        if value not in reverse_mapping:
            reverse_mapping[value] = []
        reverse_mapping[value].append(key)
    return reverse_mapping


def create_edge_matrix(vertices:list,edges:list[tuple]):
    """
    :param vertices: list of SEMS.vertices in the same order as you want the edge matrix to be.
    :param edges: list of tuples of the form (start_vertex_name,end_vertex_name)
    """
    n_vertices = len(vertices)
    edge_matrix = np.zeros((n_vertices,n_vertices),dtype=bool)
    vertex_index={vertices[i].name:i for i in range(n_vertices)}
    for edge in edges:
        start_vertex = edge[0]
        end_vertex = edge[1]
        edge_matrix[vertex_index[start_vertex]][vertex_index[end_vertex]] = True
    return edge_matrix

def get_hp_key(hdf5_file_path,hp_dict:dict):
    with h5py.File(hdf5_file_path, "r") as f:
        hp_order = f.attrs["hyperparameter_names"]

        #check if hp_order contains exactly the keys of hyperparameter_dict
        if set(hp_order) != set(hp_dict.keys()):
            raise ValueError(f"The hyperparameters provided do not exactly match the dataset. Expected {hp_order}, got {hp_dict.keys()}")

        new_dict = {hp_order[i]:hp_dict[hp_order[i]] for i in range(len(hp_order))} 
        return dict_as_string(new_dict)


def get_df_from_hdf5_experiment(hdf5_file_path, hyperparameter_dict:dict,sample_size:int, is_endogeneous="True",get_estimates = True,get_GPS = False):
    """
    Retrieve a batch of data with a certain samplesize and hyperparameters from the hdf5 file of simulated experiment data.
    The hyperparameter_dict is converted to the key, so is the sample size.
    :param hdf5_file_path: path to the hdf5 file
    :param hyperparameter_dict: dictionary of hyperparameters. Must contain one value for each hyperparameter in the hdf5 file.
    :param sample_size: int, the sample size of the data you want to retrieve.
    :param is_endogeneous: bool, whether you want to retrieve endogeneous or exogeneous data.
    """
    
    # Create a new dict where we've reordered the hyperparameters to match the order in the keys of the hdf5 file.
    #dicts are technically orderless but the order of insertion is preserved when you do dict.items() for example so I guess that's a lie.
    with h5py.File(hdf5_file_path, "r") as f:
        hp_order = f.attrs["hyperparameter_names"]

        #check if hp_order contains exactly the keys of hyperparameter_dict
        if set(hp_order) != set(hyperparameter_dict.keys()):
            raise ValueError(f"The hyperparameters provided do not exactly match the dataset. Expected {hp_order}, got {hyperparameter_dict.keys()}")

        new_dict = {hp_order[i]:hyperparameter_dict[hp_order[i]] for i in range(len(hp_order))} 
        
        #check the validity of the hyperparameters
        for key, value in new_dict.items():
            valid_values = f.attrs[key] #np array of valid values
            if value not in valid_values:
                raise ValueError(f"Invalid value for hyperparameter {key}. Valid values are {valid_values}")
        
        #check validity of sample size
        valid_sample_sizes = f.attrs["grid_of_sample_sizes"]
        if sample_size not in valid_sample_sizes:
            raise ValueError(f"Invalid sample size {sample_size}. Valid sample sizes are {valid_sample_sizes}")
        
        #Extract Data
        hyperparameter_key = dict_as_string(new_dict)
        sample_size_key = "n_" + str(sample_size)
        endogeneous_key = "endogeneous" if is_endogeneous else "exogeneous"
        group = f[hyperparameter_key]
        sample_size_group = group[sample_size_key]
        endogeneous_group = sample_size_group[endogeneous_key]

        true_counterfactual_means = group["true_counterfactual_means"][:]

        result = {}
        result["df_data"] = pd.read_hdf(hdf5_file_path, key = endogeneous_group.name)
        result["true_counterfactual_means"] = true_counterfactual_means
        if get_estimates:
            result["df_estimates"] = pd.read_hdf(hdf5_file_path, key = endogeneous_group.name + "_estimates")
        if get_GPS:
            GPS_name = endogeneous_group.name + "_f_A_given_Z"
            result["f_A_given_Z"] = f[GPS_name][:]
        #result["GPS_matrix"] = pd.read_hdf(hdf5_file_path, key = endogeneous_group.name + "_f_A_given_Z")
        return result
